#!/bin/bash
cd "$(dirname "$0")"
python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo "Done. Run: source .venv/bin/activate && python run.py"
