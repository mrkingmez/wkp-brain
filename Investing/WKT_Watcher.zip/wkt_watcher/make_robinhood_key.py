"""Makes your Robinhood crypto API key pair.

The PUBLIC key gets pasted into Robinhood's website.
The PRIVATE key goes into your .env file automatically and never leaves this PC.
"""
import base64
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

HERE = Path(__file__).resolve().parent
env = HERE / ".env"
text = env.read_text() if env.exists() else ""

if "ROBINHOOD_PRIVATE_KEY=" in text and "ROBINHOOD_PRIVATE_KEY=\n" not in text + "\n" and \
        text.split("ROBINHOOD_PRIVATE_KEY=")[1].split("\n")[0].strip():
    raise SystemExit("A Robinhood private key is already in .env. Not overwriting it.")

key = Ed25519PrivateKey.generate()
priv = base64.b64encode(key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                                          serialization.NoEncryption())).decode()
pub = base64.b64encode(key.public_key().public_bytes(serialization.Encoding.Raw,
                                                     serialization.PublicFormat.Raw)).decode()

lines = [l for l in text.splitlines() if not l.startswith(("ROBINHOOD_PRIVATE_KEY=", "ROBINHOOD_PUBLIC_KEY="))]
lines += [f"ROBINHOOD_PRIVATE_KEY={priv}", f"ROBINHOOD_PUBLIC_KEY={pub}"]
if not any(l.startswith("ROBINHOOD_API_KEY=") for l in lines):
    lines.append("ROBINHOOD_API_KEY=")
env.write_text("\n".join(lines) + "\n")

print("\nDone. Your private key is saved in .env (keep that file secret).\n")
print("Copy this PUBLIC key into Robinhood:\n")
print(pub)
print()
