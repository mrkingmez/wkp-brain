"""Offline end-to-end simulation: fake market, fake clock, real engine + database."""
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from wkt import learn, sentinel  # noqa: E402
from wkt.engine import Engine  # noqa: E402


class Clock:
    def __init__(self, t):
        self.t = t

    def __call__(self):
        return self.t


class SimFeed:
    """One continuous 5-minute price path per symbol; serves only bars that have closed by clock time."""

    def __init__(self, clock, symbols, start, days=40, seed=3):
        self.clock = clock
        rng = np.random.default_rng(seed)
        n = days * 288
        self.paths = {}
        for i, s in enumerate(symbols):
            # alternating regimes so pullbacks, dips and breakouts all occur
            regime = np.repeat(rng.normal(0, 0.0006, n // 288 + 1), 288)[:n]
            rets = rng.normal(regime, 0.004)
            close = (50 + 30 * i) * np.exp(np.cumsum(rets))
            open_ = np.r_[close[0], close[:-1]]
            wick = np.abs(rng.normal(0, 0.002, n)) * close
            df = pd.DataFrame({
                "open": open_, "high": np.maximum(open_, close) + wick,
                "low": np.minimum(open_, close) - wick, "close": close,
                "volume": rng.lognormal(12, 0.5, n)},
                index=(start + 300 * np.arange(n)).astype(int))
            self.paths[s] = df
        # long bitcoin daily history: uptrend then a sharp break, to trigger the sentinel
        d = 320
        r = np.r_[rng.normal(0.003, 0.02, d - 40), rng.normal(-0.012, 0.03, 40)]
        c = 60000 * np.exp(np.cumsum(r))
        self.btc_daily = pd.DataFrame({"open": c, "high": c * 1.02, "low": c * 0.98, "close": c,
                                       "volume": 1e4},
                                      index=(start - 86400 * np.arange(d)[::-1]).astype(int))

    def _upto(self, s, gran):
        df = self.paths[s]
        df = df[df.index + 300 <= self.clock()]
        if gran == 300:
            return df.iloc[-300:]
        g = (df.index // gran) * gran
        agg = df.groupby(g).agg({"open": "first", "high": "max", "low": "min",
                                 "close": "last", "volume": "sum"})
        agg = agg[agg.index + gran <= self.clock()]
        return agg.iloc[-300:]

    def crypto(self, sym, gran):
        if gran == 86400:
            return self.btc_daily[self.btc_daily.index + 86400 <= self.clock() + 86400 * 400]
        return self._upto(sym, gran) if sym in self.paths else None

    def stocks(self, tickers, interval, period):
        gran = 300 if interval == "5m" else 3600
        return {t: self._upto(t, gran) for t in tickers if t in self.paths}


def main():
    cfg = yaml.safe_load((HERE / "config.yaml").read_text())
    cfg["crypto"]["universe"] = ["BTC", "ETH", "SOL", "DOGE", "XRP"]
    cfg["crypto"]["min_daily_volume_usd"] = 0
    syms = cfg["crypto"]["universe"] + cfg["stocks"]["watchlist"] + cfg["stocks"]["market_gauges"]
    # Start on a Monday 00:00 ET (2026-10-05 04:00 UTC), with 25 days of warm-up history behind it
    t0 = 1759636800
    clock = Clock(t0)
    feed = SimFeed(clock, syms, start=t0 - 25 * 86400)
    tmp = Path(tempfile.mkdtemp()) / "sim.db"
    eng = Engine(cfg, tmp, feed=feed, clock=clock)

    ticks = 0
    while clock.t < t0 + 12 * 86400:
        eng.last_1h_fetch.clear()          # sim jumps 30 min per tick, so always refresh
        eng.tick()
        clock.t += 1800
        ticks += 1

    learn.grade_open_signals(eng.db, cfg)
    learn.update_weights(eng.db)
    print(f"ticks: {ticks}")
    print(learn.report(eng.db))
    c = eng.db.conn
    print("signals by status:", dict(c.execute("SELECT status, COUNT(*) FROM signals GROUP BY status").fetchall()))
    print("blocked reasons:", dict(c.execute(
        "SELECT block_reason, COUNT(*) FROM signals WHERE would_trade=0 GROUP BY block_reason").fetchall()))
    print("sentinel states:", [r[0] for r in c.execute("SELECT state FROM sentinel")])
    mx = c.execute("SELECT MAX(size_pct), MIN(size_pct) FROM signals WHERE would_trade=1").fetchone()
    print("size range of would-trade signals:", tuple(mx))
    # Monday rule check
    mon = c.execute("""SELECT COUNT(*) FROM signals WHERE would_trade=1 AND score<90 AND
                       strftime('%w', created_ts-14400, 'unixepoch')='1'""").fetchone()[0]
    print("monday trades under 90 (should be 0):", mon)
    assert mon == 0
    assert mx[0] is None or mx[0] <= 25
    assert c.execute("SELECT COUNT(*) FROM signals").fetchone()[0] > 0
    print("SIM OK")


if __name__ == "__main__":
    main()
