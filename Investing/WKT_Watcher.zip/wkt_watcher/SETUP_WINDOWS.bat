@echo off
cd /d %~dp0
echo Setting up the Warrior KING watcher...
python -m venv .venv || (echo Python not found. Install Python 3.11+ from python.org and tick "Add to PATH". & pause & exit /b)
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo Done. Double-click START_WATCHER.bat to run it.
pause
