@echo off
cd /d %~dp0
call .venv\Scripts\activate
pip install -q cryptography
python make_robinhood_key.py
pause
