@echo off
cd /d %~dp0
if exist PAUSE del PAUSE
call .venv\Scripts\activate
title WKT Watcher - close this window to turn it OFF
python run.py
pause
