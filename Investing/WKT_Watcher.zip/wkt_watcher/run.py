"""Warrior KING Trading Company - Watcher.

    python run.py            start watching (runs until you close it)
    python run.py --report   print what it has learned so far
    python run.py --once     one pass, then exit (good for a quick check)
"""
import argparse
import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from wkt import learn  # noqa: E402
from wkt.engine import Engine  # noqa: E402


def load_env(path):
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"'))


def setup_logging():
    (HERE / "logs").mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%m-%d %H:%M:%S")
    root = logging.getLogger("wkt")
    root.setLevel(logging.INFO)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    fh = RotatingFileHandler(HERE / "logs" / "watcher.log", maxBytes=5_000_000, backupCount=5)
    fh.setFormatter(fmt)
    root.addHandler(sh)
    root.addHandler(fh)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", action="store_true")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--test-text", action="store_true")
    args = ap.parse_args()

    load_env(HERE / ".env")
    setup_logging()
    cfg = yaml.safe_load((HERE / "config.yaml").read_text())
    if cfg.get("mode") != "watch":
        raise SystemExit("Only watch mode exists in this version. Set mode: watch in config.yaml.")
    eng = Engine(cfg, HERE / "data" / "wkt.db")

    if args.test_text:
        eng.alerts.enabled = True
        ok = eng.alerts.send("WKT test: your watcher can text you.", eng.now_local(), urgent=True)
        print("Text sent. Check your phone." if ok else "Text FAILED. Check the four Twilio lines in .env.")
    elif args.report:
        learn.grade_open_signals(eng.db, cfg)
        learn.update_weights(eng.db)
        print(learn.report(eng.db))
    elif args.once:
        eng.tick()
        print(learn.report(eng.db))
    else:
        try:
            eng.run(HERE / "PAUSE")
        except KeyboardInterrupt:
            print("\nStopped.")


if __name__ == "__main__":
    main()
