# Warrior KING Trading Company: Watcher (Week One)

Watch-only. It **cannot place real orders.** No API keys needed to start.

## What it does
- **Records** every 5-minute and 1-hour bar for your stocks (SOUN, QUBT, INFQ, SOFI, plus SPY/QQQ for market mood) and about 35 crypto coins.
- **Scores** three setups on 1-hour bars (trend pullback, Bollinger/RSI mean reversion, breakout) from 0 to 100.
- **Paper trades** anything 70 or higher using the locked risk rules, and logs everything 50 or higher so it can learn what scores really mean.
- **Grades itself.** Each signal is followed until it hits its stop, its target, or the time stop. The result is scored in R (1R = the amount risked).
- **Learns.** Each setup's weight drifts between 0.8 and 1.2 as real results pile up.
- **Watches Bitcoin** for your hold account: buy zone, caution, and danger alerts.

## Schedule
- Weekdays 9:30 AM to 5:00 PM: checks every minute. Stocks run during market hours only.
- After 5:00 PM and on weekends: crypto every 15 minutes.
- Bitcoin sentinel runs hourly. A daily report comes out at 4:15 PM.

## Risk rules (already set in config.yaml)
| Score | Risk if the stop hits |
|---|---|
| Under 70 | No trade (coin flip) |
| 70-79 | 0.5 percent of the account |
| 80-89 | 1 percent |
| 90+ | 2 percent |

- The stop sits 2 times the average true range below entry. The target is 2.5 times the risk.
- Position size is calculated from the stop, so a wider stop means a smaller position. The cap is 25 percent of the account.
- Time stop: 3 days for crypto, 5 days for stocks.
- Monday is a watch day, and it only trades if the score is 90 or higher.
- Kill switch: down 5 percent on the day means no new trades and a text to you.

## Setup on a home PC (Windows)
1. Install Python 3.11 or newer from python.org. Tick **"Add Python to PATH."**
2. Unzip this folder somewhere permanent, such as `C:\WKT\`.
3. Double-click **SETUP_WINDOWS.bat**.
4. Double-click **START_WATCHER.bat**. That turns it on. Close the window to turn it off.
5. Double-click **REPORT.bat** anytime to see what it has learned.

**Pause without closing it:** create an empty file named `PAUSE` in the folder. Delete the file to resume.

**Keep the PC awake:** go to Settings, then Power, and set Sleep to **Never** while plugged in.

**Run on one machine only.** Your second machine can be the backup.

## Turn on text alerts (optional, for the Bitcoin sentinel)
1. Open `.env` and fill in your Twilio SID, token, from number, and your cell number.
2. In `config.yaml`, set `alerts: enabled: true`.

During watch week, it only texts you for setups scoring 85 or higher. Bitcoin danger alerts come through even during quiet hours.

## What's not built yet (on purpose)
- Live execution through the Robinhood crypto API and Alpaca for stocks
- The Twilio YES/NO approval loop
- Rule One screening and vertical spreads

These come after the watch week proves the scoring works.
