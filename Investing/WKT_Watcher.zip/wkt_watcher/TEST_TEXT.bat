@echo off
cd /d %~dp0
call .venv\Scripts\activate
python run.py --test-text
pause
