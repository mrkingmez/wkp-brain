"""Market data feeds. No API keys needed.

Crypto: Coinbase public market data (free, keyless). Execution later happens on Robinhood;
        Robinhood's crypto API has no candle history, so we read candles here.
Stocks: Yahoo Finance via yfinance (free, keyless, fine for 5-minute bars).
"""
import time

import numpy as np
import pandas as pd
import requests

CB = "https://api.exchange.coinbase.com"
HEADERS = {"User-Agent": "wkt-watcher/1.0"}


def _closed_only(df, bar_sec):
    """Drop the candle that is still forming so signals only fire on finished bars."""
    now = time.time()
    return df[df.index + bar_sec <= now]


def crypto_candles(symbol, granularity=300):
    time.sleep(0.15)  # stay well under Coinbase public rate limits
    r = requests.get(f"{CB}/products/{symbol}-USD/candles",
                     params={"granularity": granularity}, headers=HEADERS, timeout=10)
    r.raise_for_status()
    data = r.json()
    if not data:
        return None
    df = pd.DataFrame(data, columns=["ts", "low", "high", "open", "close", "volume"])
    df = df.sort_values("ts").set_index("ts")[["open", "high", "low", "close", "volume"]].astype(float)
    return _closed_only(df, granularity)


def stock_candles(tickers, interval="5m", period="5d"):
    import yfinance as yf
    raw = yf.download(tickers, period=period, interval=interval, group_by="ticker",
                      prepost=False, progress=False, threads=True, auto_adjust=False)
    out = {}
    for t in tickers:
        try:
            d = raw[t] if isinstance(raw.columns, pd.MultiIndex) else raw
            d = d.rename(columns=str.lower)[["open", "high", "low", "close", "volume"]].dropna()
            if d.empty:
                continue
            idx = d.index if d.index.tz is not None else d.index.tz_localize("UTC")
            d.index = ((idx - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta("1s")).astype(int)
            secs = {"5m": 300, "15m": 900, "1h": 3600, "1d": 86400}[interval]
            out[t] = _closed_only(d.astype(float), secs)
        except Exception:
            continue
    return out


def stock_daily(tickers):
    return stock_candles(tickers, interval="1d", period="1y")


# ---------------- Synthetic feed for offline testing ----------------
class FakeMarket:
    """Random-walk prices with trends, dips, and breakouts so every code path gets exercised."""

    def __init__(self, seed=7):
        self.rng = np.random.default_rng(seed)

    def candles(self, n=300, bar_sec=300, start_price=100.0, end_ts=None):
        end_ts = end_ts or int(time.time()) // bar_sec * bar_sec - bar_sec
        drift = self.rng.normal(0, 0.0008)
        rets = self.rng.normal(drift, 0.006, n)
        # inject a regime: a dip or a breakout near the end
        if self.rng.random() < 0.5:
            rets[-12:-2] -= 0.004
        else:
            rets[-6:] += 0.005
        close = start_price * np.exp(np.cumsum(rets))
        open_ = np.r_[close[0], close[:-1]]
        spread = np.abs(self.rng.normal(0, 0.003, n)) * close
        high = np.maximum(open_, close) + spread
        low = np.minimum(open_, close) - spread
        vol = self.rng.lognormal(10, 0.4, n)
        vol[-3:] *= self.rng.uniform(1, 3)
        ts = end_ts - bar_sec * np.arange(n)[::-1]
        return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close, "volume": vol},
                            index=ts.astype(int))
