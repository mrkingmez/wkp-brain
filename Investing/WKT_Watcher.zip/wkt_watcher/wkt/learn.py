"""Self-grading and learning.

Every signal (traded or not) gets followed forward on 5-minute bars until it hits its stop,
its target, or the time stop. The result is stored in R (1R = the amount risked).
Then each setup's weight is nudged up or down based on how it actually performs.
"""
import time

from .scoring import SETUPS

DAY = 86400


def grade_open_signals(db, cfg):
    tstop = cfg["risk"]["time_stop_days"]
    closed = 0
    for s in db.open_signals():
        entry, stop, target = s["entry"], s["stop"], s["target"]
        risk = entry - stop
        if risk <= 0:
            db.close_signal(s["id"], "void", int(time.time()), entry, 0.0, 0.0, 0.0)
            continue
        start = s["bar_ts"] + 3600  # the 1-hour signal bar closes here; trade starts after
        bars = db.bars_after(s["symbol"], "5m", start - 1)
        mfe = s["max_favorable_r"] or 0.0
        mae = s["max_adverse_r"] or 0.0
        limit = start + tstop.get(s["asset"], 3) * DAY
        result = None
        for b in bars:
            mfe = max(mfe, (b["high"] - entry) / risk)
            mae = min(mae, (b["low"] - entry) / risk)
            hit_stop = b["low"] <= stop
            hit_tgt = b["high"] >= target
            if hit_stop:  # if both hit in the same bar, assume the worse one (conservative)
                px = min(stop, b["open"])
                result = ("loss", b["ts"], px)
                break
            if hit_tgt:
                px = max(target, b["open"]) if b["open"] > target else target
                result = ("win", b["ts"], px)
                break
            if b["ts"] >= limit:
                result = ("timeout", b["ts"], b["close"])
                break
        if result:
            status, ts, px = result
            db.close_signal(s["id"], status, ts, px, round((px - entry) / risk, 3),
                            round(mfe, 3), round(mae, 3))
            closed += 1
        else:
            db.update_excursions(s["id"], round(mfe, 3), round(mae, 3))
    return closed


def update_weights(db, min_n=8, full_n=40):
    """Weight range 0.8 - 1.2. Starts at 1.0 and only moves as real evidence piles up."""
    for setup in SETUPS:
        rows = db.conn.execute(
            "SELECT r_multiple FROM signals WHERE setup=? AND status IN ('win','loss','timeout')",
            (setup,)).fetchall()
        rs = [r[0] for r in rows]
        n = len(rs)
        if n < min_n:
            db.set_weight(setup, 1.0, n, None, None, int(time.time()))
            continue
        avg_r = sum(rs) / n
        win = sum(1 for r in rs if r > 0) / n
        confidence = min(1.0, n / full_n)
        weight = 1.0 + max(-1.0, min(1.0, avg_r)) * 0.2 * confidence
        db.set_weight(setup, round(weight, 3), n, round(win, 3), round(avg_r, 3), int(time.time()))


def paper_pl_today_pct(db, day_start_ts):
    """Realized paper P/L today, as percent of the account (for the kill switch)."""
    rows = db.conn.execute(
        """SELECT r_multiple, risk_pct FROM signals
           WHERE would_trade=1 AND status IN ('win','loss','timeout') AND exit_ts>=?""",
        (day_start_ts,)).fetchall()
    return sum((r[0] or 0) * (r[1] or 0) for r in rows)


def report(db):
    lines = []
    tot = db.conn.execute("SELECT COUNT(*) FROM bars").fetchone()[0]
    lines.append(f"Bars recorded: {tot:,}")
    for label, q in [
        ("All graded signals", "status IN ('win','loss','timeout')"),
        ("Would-have-traded", "status IN ('win','loss','timeout') AND would_trade=1"),
    ]:
        r = db.conn.execute(
            f"SELECT COUNT(*), AVG(r_multiple), SUM(r_multiple>0) FROM signals WHERE {q}").fetchone()
        n, avg, wins = r[0], r[1] or 0, r[2] or 0
        wr = (wins / n * 100) if n else 0
        lines.append(f"{label}: {n} | win rate {wr:.0f} percent | average {avg:+.2f}R")
    lines.append("By setup:")
    for r in db.conn.execute(
            """SELECT setup, COUNT(*), AVG(r_multiple), SUM(r_multiple>0) FROM signals
               WHERE status IN ('win','loss','timeout') GROUP BY setup"""):
        lines.append(f"  {r[0]}: {r[1]} graded, win {r[3] / r[1] * 100:.0f} percent, avg {r[2]:+.2f}R")
    lines.append("By score bucket (does a higher score really mean better?):")
    for r in db.conn.execute(
            """SELECT CAST(score/10 AS INT)*10 AS b, COUNT(*), AVG(r_multiple) FROM signals
               WHERE status IN ('win','loss','timeout') GROUP BY b ORDER BY b"""):
        lines.append(f"  {r[0]}-{r[0] + 9}: {r[1]} graded, avg {r[2]:+.2f}R")
    w = db.weights()
    if w:
        lines.append("Learned weights: " + ", ".join(f"{k} {v:.2f}" for k, v in w.items()))
    still_open = db.conn.execute("SELECT COUNT(*) FROM signals WHERE status='open'").fetchone()[0]
    lines.append(f"Signals still being tracked: {still_open}")
    return "\n".join(lines)
