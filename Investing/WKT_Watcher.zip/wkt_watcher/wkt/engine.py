"""The watcher loop: record, score, paper-trade, grade, learn, alert."""
import logging
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from . import feeds, learn, sentinel
from .alerts import Alerter
from .db import DB
from .scoring import evaluate, market_mood, size

log = logging.getLogger("wkt")


class RealFeed:
    def crypto(self, sym, gran):
        return feeds.crypto_candles(sym, gran)

    def stocks(self, tickers, interval, period):
        return feeds.stock_candles(tickers, interval, period)


class Engine:
    def __init__(self, cfg, db_path, feed=None, clock=None):
        self.cfg = cfg
        self.db = DB(db_path)
        self.feed = feed or RealFeed()
        self.clock = clock or time.time
        self.tz = ZoneInfo(cfg["timezone"])
        self.alerts = Alerter(cfg)
        self.last_1h_fetch = {}
        self.last_sentinel = 0
        self.last_report_day = None
        self.cache_1h = {}

    # ---------- time helpers ----------
    def now_local(self):
        return datetime.fromtimestamp(self.clock(), self.tz)

    def _hm(self, s):
        h, m = map(int, s.split(":"))
        return h * 60 + m

    def phase(self):
        n = self.now_local()
        mins = n.hour * 60 + n.minute
        sc = self.cfg["schedule"]
        weekday = n.weekday() < 5
        stock_open = weekday and self._hm(sc["market_open"]) <= mins < self._hm(sc["market_close"])
        fast = weekday and self._hm(sc["market_open"]) <= mins < self._hm(sc["fast_until"])
        return stock_open, fast

    def interval(self):
        _, fast = self.phase()
        sc = self.cfg["schedule"]
        return sc["fast_interval_sec"] if fast else sc["slow_interval_sec"]

    # ---------- one pass ----------
    def tick(self):
        stock_open, fast = self.phase()
        now = self.now_local()
        refresh_1h = 300 if fast else 900

        crypto_mood = self._scan_crypto(now, refresh_1h)
        if stock_open or self._just_closed(now):
            self._scan_stocks(now, refresh_1h, stock_open)

        closed = learn.grade_open_signals(self.db, self.cfg)
        if closed:
            log.info("graded %d signals", closed)

        if self.clock() - self.last_sentinel >= self.cfg["schedule"]["sentinel_interval_sec"]:
            self._run_sentinel(now)
            self.last_sentinel = self.clock()

        rt = self.cfg["schedule"]["daily_report_time"]
        if now.strftime("%H:%M") >= rt and self.last_report_day != now.date():
            self.last_report_day = now.date()
            learn.update_weights(self.db)
            rep = learn.report(self.db)
            log.info("DAILY REPORT\n%s", rep)
            self.db.log(int(self.clock()), "report", rep)
            short = rep.splitlines()
            self.alerts.send("WKT daily: " + " | ".join(short[1:3]), now)
        return crypto_mood

    def _just_closed(self, now):
        mins = now.hour * 60 + now.minute
        close = self._hm(self.cfg["schedule"]["market_close"])
        return now.weekday() < 5 and close <= mins < close + 20

    def _need_1h(self, key, every):
        if self.clock() - self.last_1h_fetch.get(key, 0) >= every:
            self.last_1h_fetch[key] = self.clock()
            return True
        return False

    # ---------- crypto ----------
    def _scan_crypto(self, now, refresh_1h):
        ccfg = self.cfg["crypto"]
        mood = 0.0
        refresh = self._need_1h("crypto", refresh_1h)
        if refresh:
            try:
                btc1h = self.feed.crypto("BTC", 3600)
                if btc1h is not None:
                    self.db.save_bars("BTC", "crypto", "1h", btc1h)
                    self.cache_1h["BTC"] = btc1h
            except Exception as e:
                log.warning("BTC 1h fetch failed: %s", e)
        mood = market_mood(self.cache_1h.get("BTC"))

        for sym in ccfg["universe"]:
            try:
                d5 = self.feed.crypto(sym, 300)
                if d5 is None or d5.empty:
                    continue
                self.db.save_bars(sym, "crypto", "5m", d5)
                usd_vol = float((d5.volume * d5.close).iloc[-288:].sum())
                if not refresh:
                    continue
                d1h = self.cache_1h.get(sym) if sym == "BTC" else self.feed.crypto(sym, 3600)
                if d1h is None:
                    continue
                self.db.save_bars(sym, "crypto", "1h", d1h)
                blocked = None
                if usd_vol < ccfg["min_daily_volume_usd"]:
                    blocked = "too thin (low volume)"
                self._consider(sym, "crypto", d1h, mood, now, blocked)
            except Exception as e:
                log.warning("%s crypto failed: %s", sym, e)
        return mood

    # ---------- stocks ----------
    def _scan_stocks(self, now, refresh_1h, stock_open):
        scfg = self.cfg["stocks"]
        tickers = list(dict.fromkeys(scfg["watchlist"] + scfg["market_gauges"]))
        try:
            d5 = self.feed.stocks(tickers, "5m", "5d")
            for t, df in d5.items():
                self.db.save_bars(t, "stock", "5m", df)
        except Exception as e:
            log.warning("stock 5m fetch failed: %s", e)
        if not self._need_1h("stocks", refresh_1h):
            return
        try:
            d1h = self.feed.stocks(tickers, "1h", "60d")
        except Exception as e:
            log.warning("stock 1h fetch failed: %s", e)
            return
        moods = [market_mood(d1h.get(g)) for g in scfg["market_gauges"] if g in d1h]
        mood = sum(moods) / len(moods) if moods else 0.0
        for t, df in d1h.items():
            self.db.save_bars(t, "stock", "1h", df)
            if t in scfg["watchlist"]:
                self._consider(t, "stock", df, mood, now, None if stock_open else "market closed")

    # ---------- decision ----------
    def _consider(self, sym, asset, d1h, mood, now, blocked):
        weights = self.db.weights()
        day_start = int(now.replace(hour=0, minute=0, second=0, microsecond=0).timestamp())
        kill = learn.paper_pl_today_pct(self.db, day_start) <= -self.cfg["risk"]["daily_kill_switch_pct"]
        open_rows = self.db.conn.execute(
            "SELECT symbol FROM signals WHERE status='open' AND would_trade=1").fetchall()
        open_syms = {r[0] for r in open_rows}
        for cand in evaluate(d1h, mood):
            ctx = {"kill_switch": kill, "open_count": len(open_syms),
                   "already_open": sym in open_syms, "blocked": blocked}
            s = size(cand, weights.get(cand["setup"], 1.0), self.cfg["risk"], now, ctx)
            if s["score"] < 50:
                continue  # not worth tracking
            s.update(symbol=sym, asset=asset, created_ts=int(self.clock()))
            if not self.db.add_signal(s):
                continue
            tag = "PAPER TRADE" if s["would_trade"] else f"pass ({s['block_reason']})"
            log.info("%s %s %s score %.0f entry %.4g stop %.4g target %.4g size %.1f%% -> %s",
                     asset, sym, s["setup"], s["score"], s["entry"], s["stop"], s["target"],
                     s["size_pct"], tag)
            if s["would_trade"]:
                open_syms.add(sym)
                if s["score"] >= self.cfg["alerts"]["watch_week_min_score"]:
                    self.alerts.send(
                        f"WKT PAPER ({self.cfg['mode']} mode, no real order): {sym} {s['setup']} "
                        f"score {s['score']:.0f}. Entry {s['entry']:.4g}, stop {s['stop']:.4g}, "
                        f"target {s['target']:.4g}. Size {s['size_pct']:.0f} percent of account.", now)

    # ---------- bitcoin sentinel ----------
    def _run_sentinel(self, now):
        try:
            daily = self.feed.crypto("BTC", 86400)
        except Exception as e:
            log.warning("sentinel fetch failed: %s", e)
            return
        if daily is not None:
            self.db.save_bars("BTC", "crypto", "1d", daily)
        state, price, detail = sentinel.assess(daily)
        prev = self.db.last_sentinel_state()
        if state != prev:
            self.db.add_sentinel(int(self.clock()), state, price, detail)
            if prev is not None or state in ("BUY_ZONE", "DANGER"):
                self.alerts.send(sentinel.MESSAGES[state].format(detail=detail), now,
                                 urgent=(state == "DANGER"))
        log.info("BTC sentinel: %s", state)

    # ---------- run forever ----------
    def run(self, pause_file):
        log.info("Watcher started in %s mode. Close this window or create a PAUSE file to stop.",
                 self.cfg["mode"])
        while True:
            if pause_file.exists():
                log.info("paused (delete the PAUSE file to resume)")
                time.sleep(60)
                continue
            t0 = time.time()
            try:
                self.tick()
            except Exception as e:
                log.exception("tick failed: %s", e)
            time.sleep(max(5, self.interval() - (time.time() - t0)))
