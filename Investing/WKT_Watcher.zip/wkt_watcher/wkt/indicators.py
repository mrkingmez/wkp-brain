"""Standard technical indicators on a bar DataFrame (columns: open, high, low, close, volume)."""
import numpy as np
import pandas as pd


def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()


def rsi(close, n=14):
    d = close.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    rs = up / dn.replace(0, np.nan)
    return (100 - 100 / (1 + rs)).fillna(50)


def atr(df, n=14):
    pc = df.close.shift()
    tr = pd.concat([df.high - df.low, (df.high - pc).abs(), (df.low - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def bollinger(close, n=20, k=2.0):
    mid = close.rolling(n).mean()
    sd = close.rolling(n).std()
    return mid, mid + k * sd, mid - k * sd


def macd(close, f=12, s=26, sig=9):
    line = ema(close, f) - ema(close, s)
    signal = ema(line, sig)
    return line, signal, line - signal


def stochastic(df, n=14, d=3):
    lo = df.low.rolling(n).min()
    hi = df.high.rolling(n).max()
    k = 100 * (df.close - lo) / (hi - lo).replace(0, np.nan)
    return k.fillna(50), k.rolling(d).mean().fillna(50)


def adx(df, n=14):
    """Trend strength. Under 20 = choppy/range, over 25 = trending."""
    up = df.high.diff()
    dn = -df.low.diff()
    plus_dm = np.where((up > dn) & (up > 0), up, 0.0)
    minus_dm = np.where((dn > up) & (dn > 0), dn, 0.0)
    a = atr(df, n)
    pdi = 100 * pd.Series(plus_dm, index=df.index).ewm(alpha=1 / n, adjust=False).mean() / a
    mdi = 100 * pd.Series(minus_dm, index=df.index).ewm(alpha=1 / n, adjust=False).mean() / a
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return dx.ewm(alpha=1 / n, adjust=False).mean().fillna(0)


def enrich(df):
    df = df.copy()
    df["ema9"] = ema(df.close, 9)
    df["ema20"] = ema(df.close, 20)
    df["ema50"] = ema(df.close, 50)
    df["rsi"] = rsi(df.close)
    df["atr"] = atr(df)
    df["bb_mid"], df["bb_up"], df["bb_lo"] = bollinger(df.close)
    df["macd"], df["macd_sig"], df["macd_hist"] = macd(df.close)
    df["stoch_k"], df["stoch_d"] = stochastic(df)
    df["adx"] = adx(df)
    df["vol_ratio"] = df.volume / df.volume.rolling(20).mean()
    df["hi20"] = df.high.rolling(20).max().shift(1)
    return df
