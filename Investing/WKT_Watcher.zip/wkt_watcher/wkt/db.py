"""SQLite storage: every bar, every signal, every outcome. This is the bot's memory."""
import json
import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS bars (
    symbol TEXT, asset TEXT, tf TEXT, ts INTEGER,
    open REAL, high REAL, low REAL, close REAL, volume REAL,
    PRIMARY KEY (symbol, tf, ts)
);
CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_ts INTEGER, bar_ts INTEGER, symbol TEXT, asset TEXT, setup TEXT,
    raw_score REAL, score REAL, components TEXT,
    entry REAL, stop REAL, target REAL, risk_pct REAL, size_pct REAL,
    would_trade INTEGER, block_reason TEXT,
    status TEXT DEFAULT 'open',          -- open / win / loss / timeout
    exit_ts INTEGER, exit_price REAL, r_multiple REAL, max_favorable_r REAL, max_adverse_r REAL,
    UNIQUE(symbol, setup, bar_ts)
);
CREATE TABLE IF NOT EXISTS setup_weights (
    setup TEXT PRIMARY KEY, weight REAL, n INTEGER, win_rate REAL, avg_r REAL, updated_ts INTEGER
);
CREATE TABLE IF NOT EXISTS sentinel (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, state TEXT, price REAL, detail TEXT
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, message TEXT
);
CREATE INDEX IF NOT EXISTS idx_sig_status ON signals(status);
"""


class DB:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def save_bars(self, symbol, asset, tf, df):
        rows = [(symbol, asset, tf, int(ts), r.open, r.high, r.low, r.close, r.volume)
                for ts, r in df.iterrows()]
        self.conn.executemany(
            "INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?,?)", rows)
        self.conn.commit()
        return len(rows)

    def bars_after(self, symbol, tf, ts):
        cur = self.conn.execute(
            "SELECT ts, open, high, low, close FROM bars WHERE symbol=? AND tf=? AND ts>? ORDER BY ts",
            (symbol, tf, ts))
        return cur.fetchall()

    def add_signal(self, s):
        try:
            self.conn.execute(
                """INSERT INTO signals (created_ts, bar_ts, symbol, asset, setup, raw_score, score,
                   components, entry, stop, target, risk_pct, size_pct, would_trade, block_reason)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (s["created_ts"], s["bar_ts"], s["symbol"], s["asset"], s["setup"], s["raw_score"],
                 s["score"], json.dumps(s["components"]), s["entry"], s["stop"], s["target"],
                 s["risk_pct"], s["size_pct"], int(s["would_trade"]), s.get("block_reason")))
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False  # already recorded this setup on this bar

    def open_signals(self):
        return self.conn.execute("SELECT * FROM signals WHERE status='open'").fetchall()

    def close_signal(self, sid, status, exit_ts, exit_price, r, mfe, mae):
        self.conn.execute(
            """UPDATE signals SET status=?, exit_ts=?, exit_price=?, r_multiple=?,
               max_favorable_r=?, max_adverse_r=? WHERE id=?""",
            (status, exit_ts, exit_price, r, mfe, mae, sid))
        self.conn.commit()

    def update_excursions(self, sid, mfe, mae):
        self.conn.execute("UPDATE signals SET max_favorable_r=?, max_adverse_r=? WHERE id=?",
                          (mfe, mae, sid))
        self.conn.commit()

    def weights(self):
        return {r["setup"]: r["weight"] for r in self.conn.execute("SELECT * FROM setup_weights")}

    def set_weight(self, setup, weight, n, win_rate, avg_r, ts):
        self.conn.execute("INSERT OR REPLACE INTO setup_weights VALUES (?,?,?,?,?,?)",
                          (setup, weight, n, win_rate, avg_r, ts))
        self.conn.commit()

    def last_sentinel_state(self):
        r = self.conn.execute("SELECT state FROM sentinel ORDER BY id DESC LIMIT 1").fetchone()
        return r["state"] if r else None

    def add_sentinel(self, ts, state, price, detail):
        self.conn.execute("INSERT INTO sentinel (ts, state, price, detail) VALUES (?,?,?,?)",
                          (ts, state, price, detail))
        self.conn.commit()

    def log(self, ts, kind, message):
        self.conn.execute("INSERT INTO events (ts, kind, message) VALUES (?,?,?)", (ts, kind, message))
        self.conn.commit()
