"""Setup detection, conviction scoring, and position sizing.

Swing setups are judged on 1-hour bars (room for multi-day holds).
Score 0-100. Under 70 is a coin flip = no trade. Conviction decides size, not a dollar amount.
"""
from datetime import datetime

from .indicators import enrich

SETUPS = ("trend_pullback", "mean_reversion", "breakout")


def _clip(x, lo=0, hi=100):
    return max(lo, min(hi, x))


def evaluate(df_1h, market_mood=0.0):
    """Return a list of candidate setups on the most recent closed 1-hour bar.

    market_mood: -1 (risk-off) .. +1 (risk-on), from SPY/QQQ for stocks or BTC for crypto.
    """
    if df_1h is None or len(df_1h) < 60:
        return []
    d = enrich(df_1h)
    b, p = d.iloc[-1], d.iloc[-2]
    if b.atr <= 0 or b.close <= 0:
        return []

    stretch = (b.close - b.ema20) / b.atr              # how far above the 20 EMA, in ATRs
    uptrend = b.ema20 > b.ema50 and b.close > b.ema50
    downtrend = b.ema20 < b.ema50 and b.close < b.ema50
    trending = b.adx >= 25
    cands = []

    # 1) Trend pullback: healthy uptrend, dipped to the 20 EMA, turning back up.
    if uptrend and b.low <= b.ema20 + 0.5 * b.atr and b.close > b.ema20 and b.close > b.open:
        c = {"base": 55}
        c["rsi_reset"] = 10 if 40 <= b.rsi <= 60 and b.rsi > p.rsi else 0
        c["momentum_turn"] = 8 if b.macd_hist > p.macd_hist else 0
        c["trend_strength"] = 7 if trending else 0
        cands.append(("trend_pullback", c))

    # 2) Mean reversion (Bollinger + RSI): snapped back inside the lower band from oversold.
    if p.close < p.bb_lo and b.close > b.bb_lo and p.rsi < 35 and b.rsi > p.rsi:
        c = {"base": 55}
        c["range_regime"] = 12 if b.adx < 20 else (5 if b.adx < 25 else -10)  # works in ranges, not trends
        c["deep_oversold"] = 6 if p.rsi < 28 else 0
        c["stoch_turn"] = 5 if b.stoch_k > b.stoch_d and p.stoch_k < 20 else 0
        if downtrend and trending:
            c["falling_knife"] = -15
        cands.append(("mean_reversion", c))

    # 3) Breakout: closes above the 20-bar high on real volume.
    if b.close > b.hi20 and b.vol_ratio >= 1.5 and not downtrend:
        c = {"base": 55}
        c["volume_surge"] = 12 if b.vol_ratio >= 2.5 else 6
        c["trend_strength"] = 6 if trending and b.adx > p.adx else 0
        c["close_near_high"] = 5 if (b.high - b.close) < 0.25 * (b.high - b.low + 1e-12) else 0
        cands.append(("breakout", c))

    out = []
    for setup, c in cands:
        # Shared adjustments
        if stretch > 3:
            c["overextended"] = -20      # hard-won rule: don't chase extended tickers
        elif stretch > 2:
            c["overextended"] = -8
        c["volume"] = 5 if b.vol_ratio >= 1.2 else (-5 if b.vol_ratio < 0.6 else 0)
        c["market_mood"] = round(8 * market_mood, 1)
        stop = b.close - 2.0 * b.atr
        stop_pct = (b.close - stop) / b.close * 100
        if stop_pct > 12:
            c["too_volatile"] = -10
        raw = _clip(sum(c.values()))
        out.append({"setup": setup, "raw_score": raw, "components": c,
                    "entry": float(b.close), "atr": float(b.atr), "bar_ts": int(d.index[-1])})
    return out


def market_mood(df_1h):
    """-1..+1 read of the overall tape from a gauge (SPY, QQQ, or BTC)."""
    if df_1h is None or len(df_1h) < 60:
        return 0.0
    d = enrich(df_1h)
    b = d.iloc[-1]
    m = 0.0
    m += 0.4 if b.close > b.ema50 else -0.4
    m += 0.3 if b.ema20 > b.ema50 else -0.3
    m += 0.3 if b.macd_hist > 0 else -0.3
    return max(-1.0, min(1.0, m))


def size(cand, weight, risk_cfg, now_local, ctx):
    """Apply learned weight, conviction tiers, and every block rule."""
    score = _clip(cand["raw_score"] * weight)
    stop = cand["entry"] - risk_cfg["atr_stop_multiple"] * cand["atr"]
    risk_per_unit = cand["entry"] - stop
    target = cand["entry"] + risk_cfg["reward_multiple"] * risk_per_unit

    tiers = sorted(((float(k), v) for k, v in risk_cfg["risk_per_trade_pct"].items()), reverse=True)
    risk_pct = next((v for k, v in tiers if score >= k), 0.0)
    stop_pct = risk_per_unit / cand["entry"] * 100
    size_pct = min(risk_cfg["max_position_pct"], risk_pct / stop_pct * 100) if risk_pct else 0.0

    block = None
    if score < risk_cfg["min_score_to_trade"]:
        block = "coin flip (score under %d)" % risk_cfg["min_score_to_trade"]
    elif now_local.strftime("%a") in risk_cfg["watch_days"] and score < risk_cfg["hot_score"]:
        block = "watch day - not hot enough"
    elif ctx.get("kill_switch"):
        block = "daily kill switch tripped"
    elif ctx.get("open_count", 0) >= risk_cfg["max_open_positions"]:
        block = "max open positions"
    elif ctx.get("already_open"):
        block = "already holding this symbol"
    elif ctx.get("blocked"):
        block = ctx["blocked"]

    return dict(cand, score=round(score, 1), stop=stop, target=target, risk_pct=risk_pct,
                size_pct=round(size_pct, 2), would_trade=block is None, block_reason=block)
