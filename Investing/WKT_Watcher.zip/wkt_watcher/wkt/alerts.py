"""Text alerts through Twilio. If Twilio isn't set up yet, alerts just print and go to the log."""
import logging
import os

import requests

log = logging.getLogger("wkt")


class Alerter:
    def __init__(self, cfg):
        self.enabled = cfg["alerts"]["enabled"]
        self.quiet = cfg["alerts"]["quiet_hours"]
        self.sid = os.getenv("TWILIO_ACCOUNT_SID")
        self.token = os.getenv("TWILIO_AUTH_TOKEN")
        self.from_ = os.getenv("TWILIO_FROM")
        self.to = os.getenv("ALERT_TO")

    def _in_quiet(self, now_local):
        start, end = self.quiet
        t = now_local.strftime("%H:%M")
        return t >= start or t < end if start > end else start <= t < end

    def send(self, text, now_local, urgent=False):
        log.info("ALERT: %s", text)
        if not self.enabled or not all([self.sid, self.token, self.from_, self.to]):
            return False
        if self._in_quiet(now_local) and not urgent:
            log.info("quiet hours, text held back")
            return False
        try:
            r = requests.post(
                f"https://api.twilio.com/2010-04-01/Accounts/{self.sid}/Messages.json",
                data={"From": self.from_, "To": self.to, "Body": text[:1500]},
                auth=(self.sid, self.token), timeout=15)
            r.raise_for_status()
            return True
        except Exception as e:
            log.warning("text failed: %s", e)
            return False
