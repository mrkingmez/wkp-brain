"""Bitcoin sentinel for the long-term hold account.

BUY_ZONE   - long-term uptrend intact, price pulled back: good time to add.
CAUTION    - trend is wobbling. Don't add yet.
DANGER     - trend has broken. Real risk of a deeper slide.
NEUTRAL    - nothing to do.

This flags conditions. It cannot call the exact bottom, and nobody can.
"""
from .indicators import rsi


def assess(daily):
    if daily is None or len(daily) < 210:
        return "NEUTRAL", None, "not enough daily history yet"
    c = daily.close
    price = float(c.iloc[-1])
    sma50 = float(c.rolling(50).mean().iloc[-1])
    sma200 = float(c.rolling(200).mean().iloc[-1])
    r = float(rsi(c).iloc[-1])
    high60 = float(daily.high.iloc[-60:].max())
    dd = (high60 - price) / high60 * 100

    danger = 0
    why = []
    if price < sma200:
        danger += 2; why.append("below the 200-day average")
    if sma50 < sma200:
        danger += 1; why.append("50-day under 200-day (death cross)")
    if dd > 20:
        danger += 1; why.append(f"down {dd:.0f} percent from its 60-day high")
    if price < sma50 and r < 40:
        danger += 1; why.append(f"weak momentum (RSI {r:.0f})")

    detail_base = (f"BTC {price:,.0f} | 50-day {sma50:,.0f} | 200-day {sma200:,.0f} | "
                   f"RSI {r:.0f} | off 60-day high {dd:.0f} percent")
    if danger >= 3:
        return "DANGER", price, detail_base + " | " + "; ".join(why)
    if danger == 2:
        return "CAUTION", price, detail_base + " | " + "; ".join(why)

    # Buy zone: big-picture uptrend intact but price has pulled back
    if price > sma200 and (r < 40 or (dd >= 10 and price <= sma50 * 1.03)):
        strength = "STRONG " if price <= sma200 * 1.08 and r < 35 else ""
        return "BUY_ZONE", price, f"{strength}pullback in an uptrend | " + detail_base
    return "NEUTRAL", price, detail_base


MESSAGES = {
    "BUY_ZONE": "WKT BITCOIN: Buy zone for your hold account. {detail}",
    "CAUTION": "WKT BITCOIN: Caution, trend is wobbling. Hold off adding. {detail}",
    "DANGER": "WKT BITCOIN DANGER: Trend broke. Consider protecting the hold account. {detail}",
    "NEUTRAL": "WKT BITCOIN: Back to neutral. {detail}",
}
